<?php

namespace app\admin\controller;

use app\admin\QfShop;
use think\facade\Config;
use think\facade\Cache;
use think\facade\Db;
use util\Time;

class Index extends QfShop
{
   
}
