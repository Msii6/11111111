<?php

namespace app\model;

use app\model\QfShop;

class Attach extends QfShop
{
}
