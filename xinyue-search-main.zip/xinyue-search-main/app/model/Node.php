<?php

namespace app\model;

use app\model\QfShop;

class Node extends QfShop
{
}
