<?php

return [
    // 默认磁盘
    'default' => 'public',
    // 磁盘列表
    'disks'   => [
        'public'  => [
            'type' => 'local',
            'root' => 'uploads',
        ],
    ],
];
